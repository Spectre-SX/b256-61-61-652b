const rotatingWords = document.querySelector('.rotating-word');

if (rotatingWords) {
  const words = [...rotatingWords.querySelectorAll('.rotating-word-item')];
  const interval = 2400;
  let activeIndex = 0;
  let transitionTimer;

  window.setInterval(() => {
    const current = words[activeIndex];
    const nextIndex = (activeIndex + 1) % words.length;
    const next = words[nextIndex];

    current.classList.remove('is-active', 'is-entering');
    current.classList.add('is-exiting');
    next.classList.add('is-active', 'is-entering');
    activeIndex = nextIndex;

    window.clearTimeout(transitionTimer);
    transitionTimer = window.setTimeout(() => {
      current.classList.remove('is-exiting');
      next.classList.remove('is-entering');
    }, 600);
  }, interval);
}
