// Sharperr — shared auth helpers.
// Talks to the Cloudflare Worker at API_BASE. Sessions are a cookie the
// Worker sets itself (HttpOnly), so we never touch tokens here — we just
// always send credentials: "include".

// Detect if running locally (localhost, 127.0.0.1, or file://)
const isLocal =
  typeof window !== "undefined" &&
  (window.location.hostname === "localhost" ||
   window.location.hostname === "127.0.0.1" ||
   window.location.protocol === "file:");

const API_BASE = "https://api.sharperr.dev";

async function request(path, options = {}) {
  let res;

  try {
    res = await fetch(API_BASE + path, {
      credentials: "include",
      headers: {
        "Content-Type": "application/json",
        ...(options.headers || {}),
      },
      ...options,
    });
  } catch (err) {
    throw new Error(
      isLocal
        ? `Cannot connect to API at ${API_BASE}. Make sure 'npm run dev' is running in sharperr-api!`
        : "Cannot reach Sharperr API. Please check your network connection."
    );
  }

  let data = null;

  try {
    data = await res.json();
  } catch {
    // Response has no JSON body.
  }

  if (!res.ok) {
    const errorObj = new Error(
      data?.error || `Request failed (${res.status})`
    );

    if (data?.pendingVerification) {
      errorObj.pendingVerification = true;
      errorObj.email = data.email;
    }

    throw errorObj;
  }

  return data;
}

const SharperrAuth = {
  // ------------------------------------------------------------
  // Authentication
  // ------------------------------------------------------------

  signup(email, password, confirmPassword, firstName, lastName, region) {
    return request("/auth/signup", {
      method: "POST",
      body: JSON.stringify({
        email,
        password,
        confirmPassword,
        firstName,
        lastName,
        region,
      }),
    });
  },

  verifyEmail(email, code, token) {
    return request("/auth/verify-email", {
      method: "POST",
      body: JSON.stringify({
        email,
        code,
        token,
      }),
    });
  },

  resendVerification(email) {
    return request("/auth/resend-verification", {
      method: "POST",
      body: JSON.stringify({
        email,
      }),
    });
  },

  requestPasswordReset(email) {
    return request("/auth/request-password-reset", {
      method: "POST",
      body: JSON.stringify({ email }),
    });
  },

  resetPassword(token, password, confirmPassword) {
    return request("/auth/reset-password", {
      method: "POST",
      body: JSON.stringify({ token, password, confirmPassword }),
    });
  },

  changePassword(currentPassword, newPassword, confirmPassword) {
    return request("/auth/change-password", {
      method: "POST",
      body: JSON.stringify({ currentPassword, newPassword, confirmPassword }),
    });
  },

  getSessions() {
    return request("/auth/sessions", { method: "GET" });
  },

  revokeOtherSessions() {
    return request("/auth/sessions/revoke-all", { method: "POST" });
  },

  login(email, password) {
    return request("/auth/login", {
      method: "POST",
      body: JSON.stringify({
        email,
        password,
      }),
    });
  },

  logout() {
    return request("/auth/logout", {
      method: "POST",
    });
  },

  me() {
    return request("/auth/me", {
      method: "GET",
    });
  },

  // ------------------------------------------------------------
  // Auth guards
  // ------------------------------------------------------------

  // Call on pages that require a signed-in user.
  // Redirects to login.html while preserving the current location.
  async requireAuth() {
    try {
      const { user } = await this.me();
      return user;
    } catch {
      const isSubdir =
        location.pathname.includes("/dashboard") ||
        location.pathname.includes("/admin") ||
        location.pathname.includes("/api");

      const loginPath = isSubdir
        ? "../login.html"
        : "login.html";

      const next = encodeURIComponent(
        location.pathname + location.search
      );

      location.href = `${loginPath}?next=${next}`;
      return null;
    }
  },

  // ------------------------------------------------------------
  // Admin APIs
  // ------------------------------------------------------------

  getAdminStats() {
    return request("/admin/stats", {
      method: "GET",
    });
  },

  getAdminUsers() {
    return request("/admin/users", {
      method: "GET",
    });
  },

  getAdminSessions() {
    return request("/admin/sessions", { method: "GET" });
  },

  adminRevokeSessions(userId) {
    return request("/admin/sessions/revoke", {
      method: "POST",
      body: JSON.stringify({ userId }),
    });
  },

  getAdminAuditLogs(limit = 100) {
    return request(`/admin/audit-logs?limit=${encodeURIComponent(limit)}`, { method: "GET" });
  },

  // Creates a user from the admin panel.
  //
  // plan defaults to "free" so existing callers that only provide
  // email/password/role/verified continue working.
  adminCreateUser(
    email,
    password,
    role = "user",
    verified = true,
    plan = "free"
  ) {
    return request("/admin/users/create", {
      method: "POST",
      body: JSON.stringify({
        email,
        password,
        role,
        verified,
        plan,
      }),
    });
  },

  adminToggleVerify(userId) {
    return request("/admin/users/toggle-verify", {
      method: "POST",
      body: JSON.stringify({
        userId,
      }),
    });
  },

  adminToggleRole(userId) {
    return request("/admin/users/toggle-role", {
      method: "POST",
      body: JSON.stringify({
        userId,
      }),
    });
  },

  adminDeleteUser(userId) {
    return request("/admin/users/delete", {
      method: "POST",
      body: JSON.stringify({
        userId,
      }),
    });
  },

  // ------------------------------------------------------------
  // Admin guard
  // ------------------------------------------------------------

  async requireAdmin() {
    try {
      const { user } = await this.me();

      if (
        !user ||
        (
          !user.is_admin &&
          user.role !== "admin"
        )
      ) {
        const isSubdir = location.pathname.includes("/admin");

        location.href = isSubdir
          ? "../dashboard/?error=unauthorized"
          : "dashboard/?error=unauthorized";

        return null;
      }

      return user;
    } catch {
      const isSubdir = location.pathname.includes("/admin");

      const loginPath = isSubdir
        ? "../login.html"
        : "login.html";

      location.href =
        `${loginPath}?next=${encodeURIComponent(location.pathname)}`;

      return null;
    }
  },
};
